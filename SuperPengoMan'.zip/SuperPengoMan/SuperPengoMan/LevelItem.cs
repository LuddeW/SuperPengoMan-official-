﻿namespace SuperPengoMan
{
    internal class LevelItem
    {
        public char GameObject { get; set; }

        public char Option { get; set; }
    }
}